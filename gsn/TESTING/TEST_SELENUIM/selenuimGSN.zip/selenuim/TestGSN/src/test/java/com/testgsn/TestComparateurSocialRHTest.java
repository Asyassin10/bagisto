package com.testgsn;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import static org.hamcrest.MatcherAssert.assertThat;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.qameta.allure.Allure;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import io.qameta.allure.testng.AllureTestNg;

import java.io.ByteArrayInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import static org.hamcrest.CoreMatchers.is;
@Listeners({AllureTestNg.class})
public class TestComparateurSocialRHTest {

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeClass
    @Step("Setup WebDriver and initialize browser")
    public void setup() throws MalformedURLException {
        FirefoxOptions options = new FirefoxOptions();
        driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), options);
        // Définit des délais d'attente globaux
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30)); // Implicit Wait
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30)); // Page Load Timeout

        // Initialise Explicit Wait pour toute la classe
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
    }

    @Test(priority = 18, description = "Test login functionality on the home page")
    @Step("Test login page flow")
    @Description("Test de page login première étapes")
    public void pageHome() {
        openLoginPage();
        setWindowSize();
        enterUsername("pdurant12");
        enterPassword("Csoec!2017");
        clickSubmitButton();
        attachScreenshot("Final screen after login");
        waitForUrlAndPerformActions("https://gsn-rec.experts-comptables.org/");
    }

    @Test(priority = 19, description = "Test page Social RH")
    @Description("Test page Social RH fonctionnalités")
    public void pageSocialRH() {
        clickOnThematiqueButton();
        clickOnSocialRHLink();
        attachScreenshot("After checking Social RH");
    }

    @Test(priority = 20, description = "Test pour la carte Althea Hardy")
    @Description("Vérifie les fonctionnalités de la carte Althea Hardy")
    public void testCardAltheaHardy() {
        clickCompareButton("/html/body/div[1]/main/div[2]/div/div[2]/div[2]/div/div[3]/div/div[2]/a[1]");
        try {
            Thread.sleep(5000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
        } catch (InterruptedException e) {  e.printStackTrace(); // En cas d'exception, afficher l'erreur
        }
        driver.findElement(By.id("comparator-dropdown-text")).click();
    
        attachScreenshot("elements Social RH ajouter dans comparateur");
        driver.findElement(By.id("comparator-dropdown-text")).click();
    }

    @Test(priority = 21, description = "Test pour la carte Agrume Experts")
    @Description("Vérifie les fonctionnalités de la carte Agrume Experts")
    public void testCardAgrume() {
        clickCompareButton("/html/body/div[1]/main/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/a[1]");
        try {
            Thread.sleep(5000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
        } catch (InterruptedException e) {  e.printStackTrace(); // En cas d'exception, afficher l'erreur
        }
        driver.findElement(By.id("comparator-dropdown-text")).click();
    
        attachScreenshot("elements Social RH ajouter dans comparateur");
        driver.findElement(By.id("comparator-dropdown-text")).click();
    }

    @Test(priority = 22, description = "Test pour la carte My Silae")
    @Description("Vérifie les fonctionnalités de la carte My Silae")
    public void testCardMySilae() {
        clickCompareButton("/html/body/div[1]/main/div[2]/div/div[2]/div[2]/div/div[2]/div/div[2]/a[1]");
        try {
            Thread.sleep(5000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
        } catch (InterruptedException e) {  e.printStackTrace(); // En cas d'exception, afficher l'erreur
        }
        driver.findElement(By.id("comparator-dropdown-text")).click();
    
        attachScreenshot("elements Social RH ajouter dans comparateur");
        driver.findElement(By.id("comparator-dropdown-text")).click();
       
    }

    private void clickCompareButton(String xpath) {
        try {
            WebElement compareButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
            wait.until(ExpectedConditions.elementToBeClickable(compareButton));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", compareButton);
            compareButton.click();
            System.out.println("Bouton 'Comparer' cliqué.");
        } catch (ElementClickInterceptedException e) {
            System.out.println("Erreur Selenium : L'élément est obstrué par un autre élément.");
        } catch (Exception e) {
            System.out.println("Erreur Selenium : " + e.getMessage());
        }
    }

    @Test(priority = 25, description = "Test pour cliquer sur le bouton 'Comparer' et attendre le rendu de la page")
    @Description("Clique sur le bouton 'Comparer' et attend le rendu avant de capturer l'écran")
    public void testCompareButtonClick() {
        attachScreenshot("avant");
        WebElement afficher = wait.until(ExpectedConditions.elementToBeClickable(By.id("comparator-dropdown-text")));
        afficher.click();
        WebElement comparer = wait.until(ExpectedConditions.elementToBeClickable(By.className("comparator-button")));
        comparer.click();
        WebElement h1Element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(), 'Comparateur')]")));
        attachScreenshot("After clicking on 'Comparer' and waiting for the page to render");
        Assert.assertNotNull(h1Element, "Le titre 'Comparateur' n'est pas visible.");
    }

    @Test(priority = 26, description = "Test vérifier les champs")
    @Description("Vérifier la présence de certains textes dans la source de la page")
    public void verifyTextsInPageSource() {
        // Take a screenshot before performing actions
        attachScreenshot("before_verification");
        driver.navigate().to("https://gsn-rec.experts-comptables.org");
        clickOnThematiqueButton(); 
        try {
            Thread.sleep(5000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
        } catch (InterruptedException e) {  e.printStackTrace(); // En cas d'exception, afficher l'erreur
        }
            
        clickOnSocialRHLink();

        // Attendre pendant 5 secondes avant de cliquer sur l'élément
        try {
            Thread.sleep(10000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
        } catch (InterruptedException e) {  e.printStackTrace(); // En cas d'exception, afficher l'erreur
        }
        WebElement element = driver.findElement(By.xpath("//a[contains(text(), 'Voir la fiche')]"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);

        try {
            Thread.sleep(5000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
        } catch (InterruptedException e) {  e.printStackTrace(); // En cas d'exception, afficher l'erreur
        }
        // Liste des éléments à vérifier
        String[] elementsToCheck = {
            "Gestion de la paie",
            "Gestion des temps de travail",
            "Gestion des participation et intéressement",
            "Duplication d'éléments (fiche salarié, rubrique de paie, ...)",
            "Gestion des carrières et entretiens",
            "Gestion des notes de frais",
            "Bilan social",
            "Modèle de paie par catégories de salariés",
            "Déclaration préalable à l'embauche",
            "Statistiques et tableaux de bord personnalisés",
            "Gestion de la fonction publique",
            "Coffre-fort électronique et archivage électronique des bulletins de paie",
            "Gestion du flux DSN",
            "Gestion des DSN mensuelles",
            "Contrôle et assistance aux zones de saisie obligatoires en DSN",
            "Aide à la correction des erreurs déclaratives des DSN avant envoi du flux",
            "Saisie décentralisée des variables de paie du mois avec report sur le suivant",
            "Gestion des utilisateurs et de leurs droits d'accès",
            "Saisie des évènements par les clients",
            "Paramétrage par l'utilisateur des lignes du bulletin de paie",
            "Démarrage des dossiers en cours d'année (import de DSN)",
            "Nombre de conventions collectives gérées",
            "Gestion de régimes spéciaux",
            "Intègre une solution IA",
            "Interopérabilité",
            "Import de données",
            "Export de données personnalisable",
            "Génération des écritures comptables de Paie",
            "Conformité",
            "Conforme RGPD",
            "Années de conservation de l'historique",
            "Mise à jour avec les nouvelles règlementations",
            "Accessibilité",
            "Accès cloud",
            "Application mobile disponible",
            "Sécurité des données",
            "Hébergement des données en UE",
            "Plan de récupération en cas de cyber attaque",
            "Confidentialité des données",
            "Support / Formation",
            "Hot line",
            "Chat bot",
            "Formation des utilisateurs",
            "Structure tarifaire",
            "Mode de tarification",
            "Coût de maintenance inclus",
            "Mises à jour gratuites",
            "Les 3 atouts de la solution",
            "Prérequis",
            "Fait partie d'une suite logicielle"
        };

        for (String el : elementsToCheck) {
            // Escape single quotes in the XPath expression
            String xpathExpression = "//*[contains(text(),\"" + el + "\")]";
           // System.out.print("xpathExpression => " + xpathExpression);
            List<WebElement> foundElements = driver.findElements(By.xpath(xpathExpression));

            // Display if the element is found or not
            if (foundElements.size() > 0) {
                System.out.println("Élément trouvé : " + el);
                Allure.addAttachment("Élément trouvé : " + el, "");
            } else {
                System.out.println("Élément non trouvé : " + el);
                Allure.addAttachment("Élément non trouvé : " + el, "");
            }
        }

   
        attachScreenshot("after_verification");
    }

		
    

    @Step("Open login page")
    private void openLoginPage() {
        driver.get("https://identification-rec.experts-comptables.org/cas/login?service=https%3A%2F%2Fgsn-rec.experts-comptables.org%2Fcas%2Fcallback");
    }

    @Step("Set browser window size")
    private void setWindowSize() {
        driver.manage().window().setSize(new Dimension(1854, 1048));
    }

    @Step("Enter username: {username}")
    private void enterUsername(String username) {
        WebElement usernameField = driver.findElement(By.id("username"));
        usernameField.click();
        usernameField.sendKeys(username);
    }

    @Step("Enter password")
    private void enterPassword(String password) {
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.click();
        passwordField.sendKeys(password);
    }

    @Step("Click submit button")
    private void clickSubmitButton() {
        driver.findElement(By.id("experpass_submit_button")).click();
    }

    @Step("Attach screenshot: {name}")
    private void attachScreenshot(String name) {
        byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
        Allure.addAttachment(name, new ByteArrayInputStream(screenshot));
    }

    @Step("Wait until the page is fully loaded with URL: '{expectedUrl}'")
    private void waitForUrlAndPerformActions(String expectedUrl) {
        wait.until(ExpectedConditions.urlToBe(expectedUrl));
        wait.until(webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
        attachScreenshot("Page fully loaded with URL: " + expectedUrl);
    }

    @Step("Click on the 'Thématiques' button")
    private void clickOnThematiqueButton() {
        try {
            WebElement thematiqueButton = driver.findElement(By.xpath("//button[span[text()='Thématiques']]"));
            thematiqueButton.click();
            attachScreenshot("Clicked on 'Thématiques'");
        } catch (Exception e) {
            throw new RuntimeException("Failed to click on 'Thématiques' button: " + e.getMessage());
        }
    }

    @Step("Click on the 'Social RH' link")
    private void clickOnSocialRHLink() {

            WebElement comptabiliteLink = driver.findElement(By.xpath("/html/body/div[1]/header/div[2]/div/div[1]/div/div/div[2]/ul/ul/li[2]/a"));
            comptabiliteLink.click();
         
    }

    @AfterClass
    @Step("Teardown WebDriver")
    public void teardown() {
        driver.quit();
    }
}
