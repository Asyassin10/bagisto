package com.testgsn;import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.*;
import java.util.List;

public class PDFReport {

    public void generatePDF(String fileName, List<String> steps, List<String> screenshots) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(fileName));
            document.open();

            // Ajouter des étapes
            for (String step : steps) {
                document.add(new Paragraph(step));
            }

            // Ajouter des captures d'écran
            for (String screenshotPath : screenshots) {
                Image img = Image.getInstance(screenshotPath);
                document.add(img);
                document.add(Chunk.NEWLINE); // Ajouter un saut de ligne entre les captures
            }

            document.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
