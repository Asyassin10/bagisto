package com.testgsn;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import io.qameta.allure.Allure;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import io.qameta.allure.testng.AllureTestNg;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

@Listeners({AllureTestNg.class})
public class TestCountLogiciels {

    private WebDriver driver;
    private WebDriverWait wait;

    // Listes pour stocker les étapes et captures d'écran
    private List<String> steps = new ArrayList<>();
    private List<String> screenshots = new ArrayList<>();

    @BeforeClass
    @Step("Setup WebDriver and initialize browser")
    public void setup() throws MalformedURLException {
        FirefoxOptions options = new FirefoxOptions();
        driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        steps.add("WebDriver initialized and browser setup");
    }

    @Test(priority = 48, description = "Test login functionality on the Admin Page")
    @Step("Test login page flow")
    @Description("Test de page login premiere etapes")
    public void pageAdmin() {
        openLoginPage();
        setWindowSize();
        enterUsername("ehangard@experts-comptables.org");
        enterPassword("GSM2024!");
        clickSubmitButton();
        attachScreenshot("Page admin");
    }

	/*
	 * @Test(priority = 49, description = "Count logiciels")
	 * 
	 * @Description("Test Count logiciels") public void countLogiciels() {
	 * WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	 * 
	 * // Attendre que le lien "Catalogue" soit cliquable via un sélecteur CSS plus
	 * précis WebElement element =
	 * wait.until(ExpectedConditions.elementToBeClickable(
	 * By.cssSelector("a[href*='/admin/catalog/products']"))); element.click();
	 * 
	 * // Définir le locator pour l'élément affichant le nombre de résultats By
	 * resultsLocator = By.xpath("//p[contains(text(), 'Résultats')]");
	 * Allure.addAttachment("Étape",
	 * "Attente de l'affichage du nombre de résultats");
	 * 
	 * // Attendre que le texte "Résultats" soit présent dans l'élément ciblé
	 * wait.until(ExpectedConditions.textToBePresentInElementLocated(resultsLocator,
	 * "Résultats")); WebElement resultsElement =
	 * driver.findElement(resultsLocator); String resultsText =
	 * resultsElement.getText();
	 * 
	 * verifyResults(resultsText); attachScreenshot("after admin");
	 * 
	 * // Générer le rapport PDF à la fin
	 * generatePDFReport("TestCountLogiciels_Report.pdf", steps, screenshots); }
	 */

    @Step("Open login page")
    private void openLoginPage() {
        driver.get("https://gsn-rec.experts-comptables.org/admin/login");
        steps.add("Login page opened");
    }

    @Step("Set browser window size")
    private void setWindowSize() {
        driver.manage().window().setSize(new Dimension(1854, 1048));
        steps.add("Window size set");
    }

    @Step("Enter username: {username}")
    private void enterUsername(String username) {
        WebElement usernameField = driver.findElement(By.id("email"));
        usernameField.click();
        usernameField.sendKeys(username);
        steps.add("Username entered");
    }

    @Step("Enter password")
    private void enterPassword(String password) {
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.click();
        passwordField.sendKeys(password);
        steps.add("Password entered");
    }

    @Step("Click submit button")
    private void clickSubmitButton() {
        driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/form/div[2]/button")).click();
        steps.add("Submit button clicked");
    }

    @Step("Attach screenshot: {name}")
    private void attachScreenshot(String name) {
        byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
      //  String screenshotPath = saveScreenshotToFile(name, screenshot);
      //  screenshots.add(screenshotPath);
        Allure.addAttachment(name, new ByteArrayInputStream(screenshot));
    }

	/*
	 * private String saveScreenshotToFile(String name, byte[] screenshot) { String
	 * filePath = "screenshots/" + name + ".png"; try { FileOutputStream fos = new
	 * FileOutputStream(filePath); fos.write(screenshot); fos.close(); } catch
	 * (IOException e) { e.printStackTrace(); } return filePath; }
	 */

    @Step("Verify resultats")
    public void verifyResults(String resultsText) {
        int numberOfResults = Integer.parseInt(resultsText.replaceAll("[^0-9]", ""));
        Allure.addAttachment("Nombre de résultats", "Nombre trouvé : " + numberOfResults);
        Assert.assertTrue(numberOfResults != 0, "Le nombre de résultats est inférieur ou égal à 63");
        steps.add("Results verified: " + numberOfResults);
    }

    private void generatePDFReport(String fileName, List<String> steps, List<String> screenshots) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(fileName));
            document.open();

            document.add(new Paragraph("Test Execution Report", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18)));
            document.add(new Paragraph("\n"));

            PdfPTable table = new PdfPTable(2);
            table.setWidthPercentage(100);
            table.setWidths(new int[]{1, 3});

            PdfPCell header1 = new PdfPCell(new Phrase("Step #"));
            PdfPCell header2 = new PdfPCell(new Phrase("Description"));
            table.addCell(header1);
            table.addCell(header2);

            document.add(table);
            for (int i = 0; i < steps.size(); i++) {
                table.addCell(String.valueOf(i + 1));
                table.addCell(steps.get(i));

                if (i < screenshots.size()) {
                    Image img = Image.getInstance(screenshots.get(i));
                    img.scaleToFit(250, 150);
                    document.add(img);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            document.close();
        }
    }

    @AfterClass
    @Step("Tear down and close browser")
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
