package com.testgsn;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import static org.hamcrest.MatcherAssert.assertThat;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.qameta.allure.Allure;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import io.qameta.allure.testng.AllureTestNg;

import java.io.ByteArrayInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import static org.hamcrest.CoreMatchers.is;
@Listeners({AllureTestNg.class})

public class TestComparateurDurabilite {

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeClass
    @Step("Configuration du WebDriver et initialisation du navigateur")
    public void setup() throws MalformedURLException {
        FirefoxOptions options = new FirefoxOptions();
        driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30)); // Temps d'attente implicite
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30)); // Temps d'attente pour le chargement de page

        // Initialisation de l'attente explicite pour toute la classe
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        System.out.println("WebDriver configuré avec succès.");
    }

    @Test(priority = 38, description = "Test de la fonctionnalité de connexion sur la page d'accueil")
    @Step("Test du processus de connexion")
    @Description("Vérifie la première étape de la page de connexion")
    public void pageHome() {
        ouvrirPageConnexion();
        definirTailleFenetre();
        entrerIdentifiant("pdurant12");
        entrerMotDePasse("Csoec!2017");
        cliquerBoutonConnexion();
        attacherCaptureEcran("Écran final après connexion");
        attendreUrlEtVerifierActions("https://gsn-rec.experts-comptables.org/");
    }

    @Test(priority = 39, description = "Test de la page Durabilité")
    @Description("Vérifie les fonctionnalités de la page Durabilité")
    public void pageDurabilite() {
        cliquerBoutonThematiques();
        cliquerLienDurabilite();
        attacherCaptureEcran("Après vérification de la page Durabilité");
    }

    @Test(priority = 40, description = "Test pour la carte Card1")
    @Description("Vérifie les fonctionnalités de la carte Card1")
    public void testCarte1() {
        cliquerBoutonComparer("//a[contains(text(), 'Comparer')]");
        
        // Attente et actions sur l'élément
        WebElement menuDeroulant = wait.until(ExpectedConditions.elementToBeClickable(By.id("comparator-dropdown-text")));
        menuDeroulant.click();
        attacherCaptureEcran("Élément ajouté au comparateur");
        menuDeroulant.click();
        System.out.println("Élément ajouté et retiré du comparateur.");
    }

    private void cliquerBoutonComparer(String xpath) {
        try {
            WebElement boutonComparer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
            wait.until(ExpectedConditions.elementToBeClickable(boutonComparer));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", boutonComparer);
            boutonComparer.click();
            System.out.println("Bouton 'Comparer' cliqué avec succès.");
        } catch (ElementClickInterceptedException e) {
            System.out.println("Erreur Selenium : L'élément est obstrué par un autre élément.");
        } catch (Exception e) {
            System.out.println("Erreur Selenium : " + e.getMessage());
        }
    }

    @Test(priority = 46, description = "Test de vérification des champs")
    @Description("Vérifie la présence de certains textes dans la source de la page")
    public void verifierTextesDansSourcePage() {
        attacherCaptureEcran("Avant la vérification");
        driver.navigate().to("https://gsn-rec.experts-comptables.org");
        cliquerBoutonThematiques(); 
        cliquerLienDurabilite();

        try {
            Thread.sleep(5000); // Pause pour attendre le chargement
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement element = driver.findElement(By.xpath("//a[contains(text(), 'Voir la fiche')]"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);

        String[] textesAVerifier = {
        
                "Extra-financier",
                // Thématiques principales
                "Bilan Carbone",
                "Démarche RSE",
                "Emission de Gaz à effet de serre",
                "Labellisation",
                "CSRD",
                "CSRD Volontaire",
                "Finance durable",
                "Eco-organismes",
                
                // Fonctionnalités
                "Benchmark",
                "Tableaux de bord",
                "Rapports de pilotage",
                "Mesure de la performance",
                "Planification de la réduction des émissions de GES",
                "Suivi des GES",
                "Rapports et analyses",
                "Attestation des éco-organismes",
                "Intègre une solution IA",
                
                // Interopérabilité
                "Import de données",
                "Export de données personnalisable",
                
                // Conformité
                "Conforme RGPD",
                "Mise à jour avec les nouvelles règlementations",
                
                // Accessibilité
                "Accès cloud",
                "Application mobile disponible",
                
                // Sécurité des données
                "Hébergement des données en UE",
                "Plan de récupération en cas de cyber attaque",
                "Confidentialité des données",
                
                // Support et formation
                "Hot line",
                "Chat bot",
                "Formation des utilisateurs",
                
                // Structure tarifaire
                "Mode de tarification",
                "Coût de maintenance inclus",
                "Mises à jour gratuites",
                
                // Divers
                "Les 3 atouts de la solution",
                "Prérequis",
                "Fait partie d'une suite logicielle"
            };
        for (String el : textesAVerifier) {
            // Escape single quotes in the XPath expression
            String xpathExpression = "//*[contains(text(),\"" + el + "\")]";
            // System.out.print("xpathExpression => " + xpathExpression);
            List<WebElement> foundElements = driver.findElements(By.xpath(xpathExpression));

            // Display if the element is found or not
            if (foundElements.size() > 0) {
                System.out.println("Élément trouvé : " + el);
                Allure.addAttachment("Élément trouvé : " + el, "");
            } else {
                System.out.println("Élément non trouvé : " + el);
                Allure.addAttachment("Élément non trouvé : " + el, "");
            }
        }

        attacherCaptureEcran("Après vérification des textes");
    }

    @Step("Ouvrir la page de connexion")
    private void ouvrirPageConnexion() {
        driver.get("https://identification-rec.experts-comptables.org/cas/login?service=https%3A%2F%2Fgsn-rec.experts-comptables.org%2Fcas%2Fcallback");
    }

    @Step("Définir la taille de la fenêtre du navigateur")
    private void definirTailleFenetre() {
        driver.manage().window().setSize(new Dimension(1854, 1048));
    }

    @Step("Entrer l'identifiant : {username}")
    private void entrerIdentifiant(String username) {
        WebElement champIdentifiant = driver.findElement(By.id("username"));
        champIdentifiant.click();
        champIdentifiant.sendKeys(username);
    }

    @Step("Entrer le mot de passe")
    private void entrerMotDePasse(String password) {
        WebElement champMotDePasse = driver.findElement(By.id("password"));
        champMotDePasse.click();
        champMotDePasse.sendKeys(password);
    }

    @Step("Cliquer sur le bouton de connexion")
    private void cliquerBoutonConnexion() {
        driver.findElement(By.id("experpass_submit_button")).click();
    }

    @Step("Attacher une capture d'écran : {name}")
    private void attacherCaptureEcran(String name) {
        byte[] capture = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
        Allure.addAttachment(name, new ByteArrayInputStream(capture));
    }

    @Step("Attendre que l'URL soit chargée : {expectedUrl}")
    private void attendreUrlEtVerifierActions(String expectedUrl) {
        wait.until(ExpectedConditions.urlToBe(expectedUrl));
        wait.until(webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
        attacherCaptureEcran("Page chargée avec l'URL : " + expectedUrl);
    }

    @Step("Cliquer sur le bouton 'Thématiques'")
    private void cliquerBoutonThematiques() {
        try {
            WebElement boutonThematiques = driver.findElement(By.xpath("//button[span[text()='Thématiques']]"));
            boutonThematiques.click();
            attacherCaptureEcran("Clic sur 'Thématiques'");
        } catch (Exception e) {
            throw new RuntimeException("Impossible de cliquer sur 'Thématiques' : " + e.getMessage());
        }
    }

    @Step("Cliquer sur le lien 'Durabilité'")
    private void cliquerLienDurabilite() {
        WebElement lienDurabilite = driver.findElement(By.xpath("/html/body/div[1]/header/div[2]/div/div[1]/div/div/div[2]/ul/ul/li[5]/a"));
        lienDurabilite.click();
        System.out.println("Lien 'Durabilité' cliqué avec succès.");
    }

    @AfterClass
    @Step("Fermeture du WebDriver")
    public void teardown() {
        driver.quit();
        System.out.println("WebDriver fermé.");
    }
}
