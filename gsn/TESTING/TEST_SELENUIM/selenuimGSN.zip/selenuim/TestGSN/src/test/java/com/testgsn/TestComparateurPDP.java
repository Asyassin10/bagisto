package com.testgsn;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import static org.hamcrest.MatcherAssert.assertThat;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.qameta.allure.Allure;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import io.qameta.allure.testng.AllureTestNg;

import java.io.ByteArrayInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import static org.hamcrest.CoreMatchers.is;

@Listeners({ AllureTestNg.class })
public class TestComparateurPDP {

	private WebDriver driver;
	private WebDriverWait wait;

	@BeforeClass
	@Step("Setup WebDriver and initialize browser")
	public void setup() throws MalformedURLException {
		FirefoxOptions options = new FirefoxOptions();
		driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), options);
		// Définit des délais d'attente globaux
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30)); // Implicit Wait
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30)); // Page Load Timeout

		// Initialise Explicit Wait pour toute la classe
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	}

	@Test(priority = 55, description = "Test login functionality on the home page")
	@Step("Test login page flow")
	@Description("Test de page login première étapes")
	public void pageHome() {
		openLoginPage();
		setWindowSize();
		enterUsername("pdurant12");
		enterPassword("Csoec!2017");
		clickSubmitButton();
		attachScreenshot("Final screen after login");
		 waitForUrlAndPerformActions("https://gsn-rec.experts-comptables.org/");
	}

	@Test(priority = 56, description = "Test page PDPfonctionnalités")
	@Description("Test page PDP fonctionnalités")
	public void pageData() {
		clickOnThematiqueButton();
		clickOnPDPCLink();
		attachScreenshot("After checking PDP");
	}

	@Test(priority = 57, description = "Test pour la carte Card1")
	@Description("Vérifie les fonctionnalités de la carte Card1")
	public void testCard1() {
		clickCompareButton("/html/body/div[1]/main/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/a[1]");

		try {
			Thread.sleep(5000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
		} catch (InterruptedException e) {
			e.printStackTrace(); // En cas d'exception, afficher l'erreur
		}
		driver.findElement(By.id("comparator-dropdown-text")).click();

		attachScreenshot("elements PDP ajouter dans comparateur");
		driver.findElement(By.id("comparator-dropdown-text")).click();
	}

	@Test(priority = 58, description = "Test pour la carte Card2")
	@Description("Vérifie les fonctionnalités de la carte Card2")
	public void testCard2() {
		clickCompareButton("/html/body/div[1]/main/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/a[1]");
		try {
			Thread.sleep(5000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
		} catch (InterruptedException e) {
			e.printStackTrace(); // En cas d'exception, afficher l'erreur
		}
		driver.findElement(By.id("comparator-dropdown-text")).click();

		attachScreenshot("elements PDP ajouter dans comparateur");
		driver.findElement(By.id("comparator-dropdown-text")).click();
	}

	private void clickCompareButton(String xpath) {
		try {
			WebElement compareButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
			wait.until(ExpectedConditions.elementToBeClickable(compareButton));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", compareButton);
			compareButton.click();
			System.out.println("Bouton 'Comparer' cliqué.");

		} catch (ElementClickInterceptedException e) {
			System.out.println("Erreur Selenium : L'élément est obstrué par un autre élément.");
		} catch (Exception e) {
			System.out.println("Erreur Selenium : " + e.getMessage());
		}
	}

	@Test(priority = 59, description = "Test pour cliquer sur le bouton 'Comparer' et attendre le rendu de la page")
	@Description("Clique sur le bouton 'Comparer' et attend le rendu avant de capturer l'écran")
	public void testCompareButtonClick() {
		attachScreenshot("avant");

		// Attendre et cliquer sur le menu déroulant
		WebElement afficher = wait.until(ExpectedConditions.elementToBeClickable(By.id("comparator-dropdown-text")));
		Assert.assertTrue(afficher.isDisplayed(), "Le menu déroulant 'comparator-dropdown-text' n'est pas visible.");
		Assert.assertTrue(afficher.isEnabled(), "Le menu déroulant 'comparator-dropdown-text' n'est pas activé.");
		afficher.click();
		System.out.println("Menu déroulant cliqué.");

		// Attendre et cliquer sur le bouton 'Comparer'
		WebElement comparer = wait.until(ExpectedConditions.elementToBeClickable(By.className("comparator-button")));
		Assert.assertTrue(comparer.isDisplayed(), "Le bouton 'Comparer' n'est pas visible.");
		Assert.assertTrue(comparer.isEnabled(), "Le bouton 'Comparer' n'est pas activé.");
		comparer.click();
		System.out.println("Bouton 'Comparer' cliqué.");

		Allure.addAttachment("Bouton 'Comparer' cliqué.", " ");

		// Vérifier la présence du titre <h1> après chargement
		wait.until(webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState")
				.equals("complete"));
		WebElement h1Element = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(), 'Comparateur')]")));
		attachScreenshot("Après le clic sur 'Comparer'");
		Assert.assertNotNull(h1Element, "Le titre 'Comparateur' n'est pas visible.");
		System.out.println("Titre 'Comparateur' détecté.");
		Allure.addAttachment("Titre 'Comparateur' détecté.", "");
	}

	@Test(priority = 60, description = "Test vérifier les champs")
	@Description("Vérifier la présence de certains textes dans la source de la page")
	public void verifyTextsInPageSource() {
		// Take a screenshot before performing actions
		attachScreenshot("before_verification");
		driver.navigate().to("https://gsn-rec.experts-comptables.org");
		clickOnThematiqueButton();
		try {
			Thread.sleep(5000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
		} catch (InterruptedException e) {
			e.printStackTrace(); // En cas d'exception, afficher l'erreur
		}

		clickOnPDPCLink();

		// Attendre pendant 5 secondes avant de cliquer sur l'élément
		try {
			Thread.sleep(10000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
		} catch (InterruptedException e) {
			e.printStackTrace(); // En cas d'exception, afficher l'erreur
		}
		WebElement element = driver.findElement(By.xpath("//a[contains(text(), 'Voir la fiche')]"));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);

		try {
			Thread.sleep(5000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
		} catch (InterruptedException e) {
			e.printStackTrace(); // En cas d'exception, afficher l'erreur
		}
		// Liste des éléments à vérifier
		/*
		 * String[] elementsToCheck = {
		 * "Crée ou transforme une facture au format Factur-X",
		 * "Crée ou transforme une facture au format CII",
		 * "Crée ou transforme une facture au format UBL",
		 * "Peut émettre et recevoir des factures hors périmètre du e-invoicing (B2B international, B2C, non assujettis)"
		 * ,
		 * "Peut envoyer et recevoir des factures électroniques sous des formats autres que ceux du Socle minimal"
		 * ,
		 * 
		 * // Module de facturation
		 * "Propose un module de facturation en ligne pour les clients du cabinet",
		 * "Nombre de statuts du cycle de vie gérés en dehors des statuts obligatoires",
		 * "Intègre un service de paiement", "Edition de la liasse fiscale",
		 * 
		 * // Cible visée "Cible visée (GE / ETI / PME / TPE / international)",
		 * "Sur les 36 cas d'usage, combien en gère la PDP",
		 * 
		 * // Archivage et cycle de vie des factures
		 * "Archivage des factures et de leurs cycles de vie",
		 * "Signature / scellement des factures électroniques",
		 * "Gestion du cycle entier de facturation (création, validation des factures reçues, numérisation, reporting opérationnel)"
		 * , "Concatène plusieurs sources pour générer le e-reporting",
		 * 
		 * // Interopérabilité "Nombre de PDP interfacées avec la PDP",
		 * "Certification PEPPOL", "API disponibles",
		 * "Intégration avec des solutions comptables",
		 * 
		 * // Certification et conformité "Immatriculé sous réserve par la DGFiP",
		 * 
		 * // Accessibilité "Accès cloud", "Application mobile disponible",
		 * 
		 * // Sécurité "Plan de récupération en cas de cyber attaque",
		 * "Paramétrage des droits utilisateurs", "Confidentialité des données",
		 * 
		 * // Support et formation "Hot line", "Chat bot", "Formation des utilisateurs",
		 * 
		 * // Structure tarifaire "Mode de tarification", "Coût de maintenance inclus",
		 * "Mises à jour gratuites",
		 * 
		 * // Divers "Les 3 atouts de la solution", "Prérequis",
		 * "Fait partie d'une suite logicielle" };
		 */
		
		String[] elementsToCheck = {
			    "Cible visée par la PDP (GE / ETI / PME / TPE / international)",
			    "PDP prévue pour une utilisation par le cabinet et ses dossiers clients",
			    "La PDP fait partie d'une suite logicielle, si oui, laquelle ?",
			    "Création ou transformation d'une facture au format Factur-X",
			    "Création ou transformation d'une facture au format CII",
			    "Création ou transformation d'une facture au format UBL",
			    "Emission et réception des factures hors périmètre du e-invoicing (B2B international, B2C, non assujettis)",
			    "Envoi et réception des factures électroniques sur des formats autres que ceux du Socle Minimal (EDIFACT, ...) hors obligation e-invoicing, si oui, lesquels ?",
			    "Module de saisie en ligne des factures disponible pour les clients du cabinet",
			    "Gestion des workflows de validation des factures",
			    "Gestion des workflows de validation des paiements",
			    "Nombre de statuts du cycle de vie gérés en dehors des statuts obligatoires",
			    "Service de paiement disponible",
			    "Module OCR intégré",
			    "Rapprochement automatique des factures et paiements avec mise à jour du cycle de vie",
			    "Gestion des relances factures clients en retard de paiement",
			    "Possibilité de saisie manuelle des Z de caisse par jour et taux de TVA",
			    "Génération d'un e-reporting normé à partir de plusieurs sources (caisses, logiciel dédié …)",
			    "Sur les 36 cas d'usage décrits initialement dans les spécifications, combien en gère la PDP ",
			    "Module de contrôle de validité des informations (SIREN, RIB, IBAN... ) intégré",
			    "Module complet de gestion commerciale (devis, Bdc, facture…) intégré",
			    "Module de financement des factures intégré",
			    "Service d'archivage des factures intégré",
			    "Signature / scellement des factures électroniques intégré",
			    "Génération de tableau bord de suivi des paiements des factures clients et fournisseurs",
			    "Avec combien de PDP la vôtre s'interface-t-elle ?",
			    "Votre PDP est point d'accès PEPPOL",
			    "API disponibles",
			    "Récupération simple de ses données pour le client en cas de changement de PDP",
			    "Intégration comptable",
			    "Périmètre de votre certification ISO 27001",
			    "Inscription sur la liste des immatriculations provisoires PDP de la DGFiP",
			    "Accès cloud",
			    "Application mobile disponible",
			    "Plan de récupération en cas de cyberattaque",
			    "Paramétrage des droits utilisateur",
			    "Descriptif de la garantie de confidentialité des données",
			    "Hotline",
			    "Chat bot",
			    "Support situé en France",
			    "Formation des utilisateurs proposée",
			    "Mode de tarification",
			    "Coût de maintenance inclus",
			    "Hotline incluse",
			    "Mises à jour gratuites",
			    "Les 3 atouts de la solution",
			    "Pré-requis"
			};

		for (String el : elementsToCheck) {
		    // Escape single quotes in the XPath expression
		    String xpathExpression = "//*[contains(text(),\"" + el + "\")]";
		   // System.out.print("xpathExpression => " + xpathExpression);
		    List<WebElement> foundElements = driver.findElements(By.xpath(xpathExpression));

		    // Display if the element is found or not
		    if (foundElements.size() > 0) {
		        System.out.println("Élément trouvé : " + el);
		        Allure.addAttachment("Élément trouvé : " + el, "");
		    } else {
		        System.out.println("Élément non trouvé : " + el);
		        Allure.addAttachment("Élément non trouvé : " + el, "");
		    }
		}


		attachScreenshot("after_verification");
	}

	@Step("Open login page")
	private void openLoginPage() {
		driver.get(
				"https://identification-rec.experts-comptables.org/cas/login?service=https%3A%2F%2Fgsn-rec.experts-comptables.org%2Fcas%2Fcallback");
	}

	@Step("Set browser window size")
	private void setWindowSize() {
		driver.manage().window().setSize(new Dimension(1854, 1048));
	}

	@Step("Enter username: {username}")
	private void enterUsername(String username) {
		WebElement usernameField = driver.findElement(By.id("username"));
		usernameField.click();
		usernameField.sendKeys(username);
	}

	@Step("Enter password")
	private void enterPassword(String password) {
		WebElement passwordField = driver.findElement(By.id("password"));
		passwordField.click();
		passwordField.sendKeys(password);
	}

	@Step("Click submit button")
	private void clickSubmitButton() {
		driver.findElement(By.id("experpass_submit_button")).click();
	}

	@Step("Attach screenshot: {name}")
	private void attachScreenshot(String name) {
		byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		Allure.addAttachment(name, new ByteArrayInputStream(screenshot));
	}

	@Step("Wait until the page is fully loaded with URL: '{expectedUrl}'")
	private void waitForUrlAndPerformActions(String expectedUrl) {
		wait.until(ExpectedConditions.urlToBe(expectedUrl));
		wait.until(webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState")
				.equals("complete"));
		attachScreenshot("Page fully loaded with URL: " + expectedUrl);
	}

	@Step("Click on the 'Thématiques' button")
	private void clickOnThematiqueButton() {
		try {
			WebElement thematiqueButton = driver.findElement(By.xpath("//button[span[text()='Thématiques']]"));
			thematiqueButton.click();
			Allure.addAttachment("bouton trouver et clické", "");
			attachScreenshot("Clicked on 'Thématiques'");
		} catch (Exception e) {
			throw new RuntimeException("Failed to click on 'Thématiques' button: " + e.getMessage());
		}
	}

	@Step("Click on the 'PDP' link")
	private void clickOnPDPCLink() {
		Allure.addAttachment("Click on the 'PDP' link", "");
		WebElement pDpLink = driver
				.findElement(By.xpath("/html/body/div[1]/header/div[2]/div/div[1]/div/div/div[2]/ul/ul/li[7]/a"));
		pDpLink.click();

	}

	@AfterClass
	@Step("Teardown WebDriver")
	public void teardown() {
		driver.quit();
	}
}
