package com.testgsn;

import java.io.ByteArrayInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.qameta.allure.Allure;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class TestApercuTest {
	private WebDriver driver;
	private WebDriverWait wait;
	private Map<String, Object> vars;
	  JavascriptExecutor js;
	@BeforeClass
	@Step("Setup WebDriver and initialize browser")
	public void setup() throws MalformedURLException {
		FirefoxOptions options = new FirefoxOptions();
		driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), options);
		js = (JavascriptExecutor) driver;
	    vars = new HashMap<String, Object>();
		// Définit des délais d'attente globaux
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30)); // Implicit Wait
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30)); // Page Load Timeout

		// Initialise Explicit Wait pour toute la classe
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	}
	
	@Test(priority = 100, description = "Test apercu")
	@Step("Test login page flow")
	@Description("Test BO apercu logiciel")
	public void testApercu() {

	    // Test name: testApercu
	    // Step # | name | target | value
	    // 1 | open | /admin/login | 
	    driver.get("https://gsn-rec.experts-comptables.org/admin/login");
	    // 2 | setWindowSize | 1690x956 | 
	    driver.manage().window().setSize(new Dimension(1690, 956));
	    // 3 | type | id=email | jmenier@experts-comptables.org
	    driver.findElement(By.id("email")).sendKeys("jmenier@experts-comptables.org");
	    // 4 | type | id=password | GSM2024!
	    driver.findElement(By.id("password")).sendKeys("GSM2024!");
	    // 5 | click | id=email | 
	    driver.findElement(By.id("email")).click();
	    // 6 | click | id=password | 
	    driver.findElement(By.id("password")).click();
	    // 7 | click | css=.border-blue-700 | 
	    driver.findElement(By.cssSelector(".border-blue-700")).click();
	    // 8 | click | css=.group\/item:nth-child(2) > .flex > .text-gray-600 | 
	    driver.findElement(By.cssSelector(".group\\/item:nth-child(2) > .flex > .text-gray-600")).click();
	    // 9 | mouseOver | css=.row:nth-child(2) .w-full:nth-child(4) > .primary-button | 
	    {
	      WebElement element = driver.findElement(By.cssSelector(".row:nth-child(2) .w-full:nth-child(4) > .primary-button"));
	      Actions builder = new Actions(driver);
	      builder.moveToElement(element).perform();
	    }
	    // 10 | mouseOut | css=.row:nth-child(2) .w-full:nth-child(4) > .primary-button | 
	    {
	      WebElement element = driver.findElement(By.tagName("body"));
	      Actions builder = new Actions(driver);
	      builder.moveToElement(element, 0, 0).perform();
	    }
	    attachScreenshot("screen after login");
	    // 11 | click | css=.row:nth-child(2) .w-full:nth-child(5) > .primary-button | 
	    vars.put("window_handles", driver.getWindowHandles());
	    // 12 | storeWindowHandle | root | 
	    driver.findElement(By.cssSelector(".row:nth-child(2) .w-full:nth-child(5) > .primary-button")).click();
	    // 13 | selectWindow | handle=${win6204} | 
	    vars.put("win6204", waitForWindow(2000));
	    // 14 | close |  | 
	    vars.put("root", driver.getWindowHandle());
	    // 15 | selectWindow | handle=${root} | 
	    driver.switchTo().window(vars.get("win6204").toString());
	    driver.close();
	    driver.switchTo().window(vars.get("root").toString());
	    
	    attachScreenshot("screen after apercu");}
	@Step("Attach screenshot: {name}")
	private void attachScreenshot(String name) {
		byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		Allure.addAttachment(name, new ByteArrayInputStream(screenshot));
	}
	
	public String waitForWindow(int timeout) {
	    try {
	      Thread.sleep(timeout);
	    } catch (InterruptedException e) {
	      e.printStackTrace();
	    }
	    Set<String> whNow = driver.getWindowHandles();
	    Set<String> whThen = (Set<String>) vars.get("window_handles");
	    if (whNow.size() > whThen.size()) {
	      whNow.removeAll(whThen);
	    }
	    return whNow.iterator().next();
	  }
	@AfterClass
	@Step("Teardown WebDriver")
	public void teardown() {
		driver.quit();
	}
	}