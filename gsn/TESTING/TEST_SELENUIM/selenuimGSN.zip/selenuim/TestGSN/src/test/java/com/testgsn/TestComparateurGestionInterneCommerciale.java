package com.testgsn;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import static org.hamcrest.MatcherAssert.assertThat;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.apache.commons.lang3.StringEscapeUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.qameta.allure.Allure;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import io.qameta.allure.testng.AllureTestNg;

import java.io.ByteArrayInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import static org.hamcrest.CoreMatchers.is;
@Listeners({AllureTestNg.class})
public class TestComparateurGestionInterneCommerciale{

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeClass
    @Step("Setup WebDriver and initialize browser")
    public void setup() throws MalformedURLException {
        FirefoxOptions options = new FirefoxOptions();
        driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), options);
        // Définit des délais d'attente globaux
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30)); // Implicit Wait
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30)); // Page Load Timeout

        // Initialise Explicit Wait pour toute la classe
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
    }

    @Test(priority = 37, description = "Test login functionality on the home page")
    @Step("Test login page flow")
    @Description("Test de page login première étapes")
    public void pageHome() {
        openLoginPage();
        setWindowSize();
        enterUsername("pdurant12");
        enterPassword("Csoec!2017");
        clickSubmitButton();
        attachScreenshot("Final screen after login");
        waitForUrlAndPerformActions("https://gsn-rec.experts-comptables.org/");
    }

    @Test(priority = 38, description = "Test page Gestion interne & Commerciale fonctionnalités")
    @Description("Test page Gestion interne & Commerciale fonctionnalités")
    public void pageData() {
        clickOnThematiqueButton();
        clickOnGICLink();
        attachScreenshot("After checking Gestion interne & Commerciale");
    }

    @Test(priority = 39, description = "Test pour la carte Card1")
    @Description("Vérifie les fonctionnalités de la carte Card1")
    public void testCard1() {
        clickCompareButton("/html/body/div[1]/main/div[2]/div/div[2]/div[2]/div/div[3]/div/div[2]/a[1]");
        
        try {
            Thread.sleep(5000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
        } catch (InterruptedException e) {  e.printStackTrace(); // En cas d'exception, afficher l'erreur
        }
        driver.findElement(By.id("comparator-dropdown-text")).click();
    
        attachScreenshot("elements Gestion interne & Commerciale ajouter dans comparateur");
        driver.findElement(By.id("comparator-dropdown-text")).click();
    }

    @Test(priority = 40, description = "Test pour la carte Card2")
    @Description("Vérifie les fonctionnalités de la carte Card2")
    public void testCard2() {
        clickCompareButton("/html/body/div[1]/main/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/a[1]");
        try {
            Thread.sleep(5000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
        } catch (InterruptedException e) {  e.printStackTrace(); // En cas d'exception, afficher l'erreur
        }
        driver.findElement(By.id("comparator-dropdown-text")).click();
    
        attachScreenshot("elements Gestion interne & Commerciale ajouter dans comparateur");
        driver.findElement(By.id("comparator-dropdown-text")).click();
    }

    @Test(priority = 41, description = "Test pour la carte Card3")
    @Description("Vérifie les fonctionnalités de la carte Card3")
    public void testCard3() {
        clickCompareButton("/html/body/div[1]/main/div[2]/div/div[2]/div[2]/div/div[2]/div/div[2]/a[1]");
        try {
            Thread.sleep(5000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
        } catch (InterruptedException e) {  e.printStackTrace(); // En cas d'exception, afficher l'erreur
        }
        driver.findElement(By.id("comparator-dropdown-text")).click();
    
        attachScreenshot("elements Gestion interne & Commerciale ajouter dans comparateur");
        driver.findElement(By.id("comparator-dropdown-text")).click();
    }

    private void clickCompareButton(String xpath) {
        try {
            WebElement compareButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
            wait.until(ExpectedConditions.elementToBeClickable(compareButton));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", compareButton);
            compareButton.click();
            System.out.println("Bouton 'Comparer' cliqué.");
            
        } catch (ElementClickInterceptedException e) {
            System.out.println("Erreur Selenium : L'élément est obstrué par un autre élément.");
        } catch (Exception e) {
            System.out.println("Erreur Selenium : " + e.getMessage());
        }
    }

    @Test(priority = 42, description = "Test pour cliquer sur le bouton 'Comparer' et attendre le rendu de la page")
    @Description("Clique sur le bouton 'Comparer' et attend le rendu avant de capturer l'écran")
    public void testCompareButtonClick() {
        attachScreenshot("avant");
        
        // Attendre et cliquer sur le menu déroulant
        WebElement afficher = wait.until(ExpectedConditions.elementToBeClickable(By.id("comparator-dropdown-text")));
        Assert.assertTrue(afficher.isDisplayed(), "Le menu déroulant 'comparator-dropdown-text' n'est pas visible.");
        Assert.assertTrue(afficher.isEnabled(), "Le menu déroulant 'comparator-dropdown-text' n'est pas activé.");
        afficher.click();
        System.out.println("Menu déroulant cliqué.");

        // Attendre et cliquer sur le bouton 'Comparer'
        WebElement comparer = wait.until(ExpectedConditions.elementToBeClickable(By.className("comparator-button")));
        Assert.assertTrue(comparer.isDisplayed(), "Le bouton 'Comparer' n'est pas visible.");
        Assert.assertTrue(comparer.isEnabled(), "Le bouton 'Comparer' n'est pas activé.");
        comparer.click();
        System.out.println("Bouton 'Comparer' cliqué.");
        
        Allure.addAttachment("Bouton 'Comparer' cliqué.", " ");

        // Vérifier la présence du titre <h1> après chargement
        wait.until(webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
        WebElement h1Element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(), 'Comparateur')]")));
        attachScreenshot("Après le clic sur 'Comparer'");
        Assert.assertNotNull(h1Element, "Le titre 'Comparateur' n'est pas visible.");
        System.out.println("Titre 'Comparateur' détecté.");
        Allure.addAttachment("Titre 'Comparateur' détecté.", "");
    }

    @Test(priority = 43, description = "Test vérifier les champs")
    @Description("Vérifier la présence de certains textes dans la source de la page")
    public void verifyTextsInPageSource() {
        // Take a screenshot before performing actions
        attachScreenshot("before_verification");
        driver.navigate().to("https://gsn-rec.experts-comptables.org");
        clickOnThematiqueButton(); 
        try {
            Thread.sleep(5000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
        } catch (InterruptedException e) {  e.printStackTrace(); // En cas d'exception, afficher l'erreur
        }
            
        clickOnGICLink();

        // Attendre pendant 5 secondes avant de cliquer sur l'élément
        try {
            Thread.sleep(10000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
        } catch (InterruptedException e) {  e.printStackTrace(); // En cas d'exception, afficher l'erreur
        }
        WebElement element = driver.findElement(By.xpath("//a[contains(text(), 'Voir la fiche')]"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);

        try {
            Thread.sleep(5000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
        } catch (InterruptedException e) {  e.printStackTrace(); // En cas d'exception, afficher l'erreur
        }
        // Liste des éléments à vérifier
        String[] elementsToCheck = {

        	    "Gestion des clients",
        	    "Gestion des prospects",
        	    "Gestion des affaires",
        	    "Historique des interactions",
        	    "Gestion des tâches clients",
        	    "Relance automatique des tâches",
        	    
        	    // Gestion des devis, factures et paiements
        	    "Gestion des devis",
        	    "Création des factures",
        	    "Factures au format facture électronique",
        	    "Gestion des paiements",
        	    "Gestion des relances des impayés",
        	    "Collecte de documents",
        	    "Envoi d'emails via le logiciel",
        	    
        	    // Suivi et rapports
        	    "Suivi des demandes / tickets",
        	    "Champs paramétrables",
        	    "Rapports paramétrables",
        	    "Dashboards personnalisables",
        	    "Double accès cabinet et client",
        	    
        	    // Gestion de production et projets
        	    "Génération des lettres de mission",
        	    "Gestion des temps",
        	    "Facturation des temps",
        	    "Suivi de production du cabinet",
        	    "Gestion multi sites",
        	    "Espace collaboratif pour les collaborateurs",
        	    "Gestion de projet",
        	    
        	    // Gestion des documents
        	    "Gestion électronique des documents",
        	    " Espace dédié par dossier / client ",
                " Accès par le client à son dossier ",
        	    
        	    // Intégration IA et interopérabilité
        	    "Intègre une solution IA",
        	    "Import de données",
        	    "Export de données personnalisable",
        	    "API disponibles",
        	    "Interopérable avec un logiciel de comptabilité",
        	    
        	    // Conformité et accessibilité
        	    "Conforme RGPD",
        	    "Mise à jour avec les nouvelles règlementations",
        	    "Accès cloud",
        	    "Application mobile disponible",
        	    
        	    // Sécurité
        	    "Hébergement des données en UE",
        	    "Plan de récupération en cas de cyber attaque",
        	    "Paramétrage des droits utilisateurs",
        	    "Confidentialité des données",
        	    
        	    // Support et formation
        	    "Hot line",
        	    "Chat bot",
        	    "Formation des utilisateurs",
        	    
        	    // Structure tarifaire
        	    "Mode de tarification",
        	    "Coût de maintenance inclus",
        	    "Mises à jour gratuites",
        	    
        	    // Divers
        	    "Les 3 atouts de la solution",
        	    "Prérequis",
        	    "Fait partie d'une suite logicielle"
        	};


        // Vérification de chaque texte
        for (String el : elementsToCheck) {
            // Escape single quotes in the XPath expression
            String xpathExpression = "//*[contains(text(),\"" + el + "\")]";
           // System.out.print("xpathExpression => " + xpathExpression);
            List<WebElement> foundElements = driver.findElements(By.xpath(xpathExpression));

            // Display if the element is found or not
            if (foundElements.size() > 0) {
                System.out.println("Élément trouvé : " + el);
                Allure.addAttachment("Élément trouvé : " + el, "");
            } else {
                System.out.println("Élément non trouvé : " + el);
                Allure.addAttachment("Élément non trouvé : " + el, "");
            }
        }

        attachScreenshot("after_verification");
    }

		
    

    @Step("Open login page")
    private void openLoginPage() {
        driver.get("https://identification-rec.experts-comptables.org/cas/login?service=https%3A%2F%2Fgsn-rec.experts-comptables.org%2Fcas%2Fcallback");
    }

    @Step("Set browser window size")
    private void setWindowSize() {
        driver.manage().window().setSize(new Dimension(1854, 1048));
    }

    @Step("Enter username: {username}")
    private void enterUsername(String username) {
        WebElement usernameField = driver.findElement(By.id("username"));
        usernameField.click();
        usernameField.sendKeys(username);
    }

    @Step("Enter password")
    private void enterPassword(String password) {
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.click();
        passwordField.sendKeys(password);
    }

    @Step("Click submit button")
    private void clickSubmitButton() {
        driver.findElement(By.id("experpass_submit_button")).click();
    }

    @Step("Attach screenshot: {name}")
    private void attachScreenshot(String name) {
        byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
        Allure.addAttachment(name, new ByteArrayInputStream(screenshot));
    }

    @Step("Wait until the page is fully loaded with URL: '{expectedUrl}'")
    private void waitForUrlAndPerformActions(String expectedUrl) {
        wait.until(ExpectedConditions.urlToBe(expectedUrl));
        wait.until(webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
        attachScreenshot("Page fully loaded with URL: " + expectedUrl);
    }

    @Step("Click on the 'Thématiques' button")
    private void clickOnThematiqueButton() {
        try {
            WebElement thematiqueButton = driver.findElement(By.xpath("//button[span[text()='Thématiques']]"));
            thematiqueButton.click();
            Allure.addAttachment("bouton trouver et clické","");
            attachScreenshot("Clicked on 'Thématiques'");
        } catch (Exception e) {
            throw new RuntimeException("Failed to click on 'Thématiques' button: " + e.getMessage());
        }
    }

    @Step("Click on the 'Gestion interne & Commerciale' link")
    private void clickOnGICLink() {
    	 Allure.addAttachment("Click on the 'Gestion interne & Commerciale' link","");
            WebElement dataLink = driver.findElement(By.xpath("/html/body/div[1]/header/div[2]/div/div[1]/div/div/div[2]/ul/ul/li[4]/a"));
            dataLink.click();
         
    }

    @AfterClass
    @Step("Teardown WebDriver")
    public void teardown() {
        driver.quit();
    }
}
