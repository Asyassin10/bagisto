package com.testgsn;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.Assert;

import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.qameta.allure.Allure;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import io.qameta.allure.testng.AllureTestNg;

import org.apache.commons.lang3.StringEscapeUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.ByteArrayInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

@Listeners({ AllureTestNg.class })
public class TestHomePage {

	private WebDriver driver;
	private WebDriverWait wait;

	@BeforeClass
	@Step("Setup WebDriver and initialize browser")
	public void setup() throws MalformedURLException {
		FirefoxOptions options = new FirefoxOptions();
		driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), options);
		// Définit des délais d'attente globaux
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30)); // Implicit Wait
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30)); // Page Load Timeout

		// Initialise Explicit Wait pour toute la classe
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	}

	@Test(priority = 1, description = "Test login functionality on the home page")
	@Step("Test login page flow")
	@Description("test de page login premiere etapes")
	public void pageHome() {
		openLoginPage();
		setWindowSize();
		enterUsername("pdurant12");
		enterPassword("Csoec!2017");
		clickSubmitButton();
		attachScreenshot("Final screen after login");
		waitForUrlAndPerformActions("https://gsn-rec.experts-comptables.org/");

	}

	@Test(priority = 2, description = "filtres  de Comptabilité - Précomptabilité")
	@Description("Test page comptabilite fonctionnalités ")
	public void pageComptabilite() {
		clickOnThematiqueButton();
		clickOnComptabilitePrecomptabiliteLink();

		System.out.println("filtres");
		String[] textLines = { "Solution de comptabilité ou de précomptabilité", "Rapprochement bancaire et lettrage",
				"Module de facturation compatible facturation électronique", "Gestion de l'IR",
				"Gestion des notes de frais", "Module OCR", "Prévisionnels de budget",
				"Utilise un RPA (robotic Process Automation)", "Intègre une solution IA", "Import de données",
				"Export de données personnalisable", "Intégration bureautique type Excel ou Power BI",
				"Hébergement des données" };
		/*
		 * ,
		 */
		verifyTextLinesInPageSource(textLines);
		attachScreenshot("After checking filters");
	}

	@Test(priority = 3, description = "filtres  Data")
	@Description("Test page Data ")
	public void pageData() {

		// waitForUrlAndPerformActions("https://gsn-rec.experts-comptables.org/");
		clickOnThematiqueButton();
		clickOnDataLink();

		System.out.println("filtres");
		String[] textLines = { StringEscapeUtils.escapeHtml4("Importation et exploitation d'Open data"),
				"Datavisualisation / tableaux de bord", "Comparaison sectorielle", "Rapports personnalisables",
				"Module prédictif", "Intègre une solution IA",
				"Interconnexions à des sources de données", "Hébergement des données en UE" };

		verifyTextLinesInPageSource(textLines);
		attachScreenshot("After checking filters");
	}

	@Test(priority = 4, description = "filtres  Social-RH")
	@Description("Test page Social-RH ")
	public void pageSocialRH() {

		// waitForUrlAndPerformActions("https://gsn-rec.experts-comptables.org/");
		clickOnThematiqueButton();
		clickOnSocialRHLink();

		System.out.println("filtres");
		String[] textLines = { "Gestion de la paie", "Gestion des temps de travail",
				"Gestion des carrieres et entretiens", "Gestion des notes de frais", "Bilan social",
				"Modèle de paie par categories de salariés", "Déclaration préalable à l'embauche",
				"Coffre-fort électronique et archivage électronique des bulletins de paie",
				"Démarrage des dossiers en cours d'année (import de DSN)",
				"Génération des écritures comptables de Paie", "Hébergement des données en UE" };

		verifyTextLinesInPageSource(textLines);
		attachScreenshot("After checking filters");
	}

	@Test(priority = 5, description = "filtres   Gestion interne et Commerciale")
	@Description("Test page  Gestion interne et Commerciale ")
	public void pageGestionInterneCommerciale() {

		// waitForUrlAndPerformActions("https://gsn-rec.experts-comptables.org/");
		clickOnThematiqueButton();
		clickOnGestionInterneCommercialeLink();

		System.out.println("filtres");
		String[] textLines = { "Historique des interactions", "Relance automatique des tâches", "Gestion des devis",
				"Création des factures", "Gestion des paiements", "Génération des lettres de mission",
				"Gestion des temps", "Gestion multi sites", "Interopérable avec un logiciel de comptabilité",
				"Hébergement des données en UE" };

		verifyTextLinesInPageSource(textLines);
		attachScreenshot("After checking filters");
	}

	@Test(priority = 6, description = "filtres Durabilité")
	@Description("Test page  Durabilité ")
	public void pageDurabilite() {

		// waitForUrlAndPerformActions("https://gsn-rec.experts-comptables.org/");
		clickOnThematiqueButton();
		long startTime = System.currentTimeMillis();
		clickOnDurabiliteLink();
		// Calculer le temps de chargement en secondes

		long endTime = System.currentTimeMillis();
		long loadTime = (endTime - startTime) / 1000;

		System.out.println("filtres");
		String[] textLines = { "Extra-financier", "Bilan Carbone", "Démarche RSE", "Emission de Gaz à effet de serre",
				"Labellisation", "CSRD", "CSRD Volontaire", "Finance durable", "Eco-organismes",
				"Hébergement des données en UE" };

		verifyTextLinesInPageSource(textLines);
		attachScreenshot("After checking filters en " + loadTime + "Seconds");
	}

	@Test(priority = 7, description = "filtres JuridiqueFiscal")
	@Description("Test page  JuridiqueFiscal ")
	public void pageJuridiqueFiscal() {

		// waitForUrlAndPerformActions("https://gsn-rec.experts-comptables.org/");
		clickOnThematiqueButton();
		clickOnJuridiqueFiscalLink();

		System.out.println("filtres");
		String[] textLines = {

				"Génération automatisée du compte-rendu de mission", "Importation de la liasse fiscale",
				"Gestion des formalités juridiques (création / modification)", "Gestion des AG",
				"Recouvrement de créances", "Rédaction, analyse de documents juridiques", "Gestion des contrats",
				"Génération des lettres de mission", "Intègre une solution IA", "Hébergement des données en UE" };
		verifyTextLinesInPageSource(textLines);
		attachScreenshot("After checking filters");
	}

	@Test(priority = 8, description = "filtres PDP")
	@Description("Test page  PDP ")
	public void pagePDP() {

		// waitForUrlAndPerformActions("https://gsn-rec.experts-comptables.org/");
		clickOnThematiqueButton();
		clickOnPDPLink();

		System.out.println("filtres");
		String[] textLines = { 
				  "Création ou transformation d'une facture au format Factur-X",
				    "Emission et réception des factures hors périmètre du e-invoicing (B2B international, B2C, non assujettis)",
				    "Envoi et réception des factures électroniques sur des formats autres que ceux du Socle Minimal (EDIFACT, ...) hors obligation e-invoicing",
				    "Module de saisie en ligne des factures disponible pour les clients du cabinet",
				    "Service de paiement disponible",
				    "Possibilité de saisie manuelle des Z de caisse par jour et taux de TVA",
				    "Module complet de gestion commerciale (devis, Bdc, facture…) intégré",
				    "Service d'archivage des factures intégré",
				    "Signature / scellement des factures électroniques intégré",
				    "Votre PDP est point d'accès PEPPOL",
				    "Inscription sur la liste des immatriculations provisoires PDP de la DGFiP"};
		verifyTextLinesInPageSourcePDP(textLines);
		attachScreenshot("After checking filters");
	}

	@Test(priority = 9, description = "filtres Gestion patrimoine")
	@Description("Test page  Gestion patrimoine ")
	public void pageGestionPatrimoine() {

		// waitForUrlAndPerformActions("https://gsn-rec.experts-comptables.org/");
		clickOnThematiqueButton();
		clickOnGestionPatrimoineLink();

		System.out.println("filtres");
		String[] textLines = { "Bilan patrimonial", "Projections", "Simulation fiscale",
				"Simulation succession", "Diagnostic Retraite", "Intègre une solution IA",
				"Hébergement des données en UE" };
		verifyTextLinesInPageSource(textLines);
		attachScreenshot("After checking filters");
	}

	@Test(priority = 10, description = "filtres Gestion trésorerie-financement")
	@Description("Test page  Gestion trésorerie-financement ")
	public void pageGestionTresorerieFinancement() {

		// waitForUrlAndPerformActions("https://gsn-rec.experts-comptables.org/");
		clickOnThematiqueButton();
		clickOnGestionTresorerieFinancementLink();

		System.out.println("filtres");
		String[] textLines = { "Reporting sur la santé financière de l'entreprise",
				  "Anticipation des risques financiers", "Synchronisation bancaire",
				  "Rapprochement bancaire", "Flux de caisse", "Relances clients",
				  "Emission des règlements", "Intègre une solution IA",
				  "Interopérable avec un logiciel comptable",
				  "Interopérable avec un logiciel de gestion / caisse",
				  "Hébergement des données en UE"
				  };
		verifyTextLinesInPageSource(textLines);
		attachScreenshot("After checking filters");
	}

	@Test(priority = 11, description = "filtres Signature électronique, Télétransmission, archivage")
	@Description("Test page  Gestion Signature électronique, Télétransmission, archivage ")
	public void pageSignatureTeletravailArchivage() {

		// waitForUrlAndPerformActions("https://gsn-rec.experts-comptables.org/");
		clickOnThematiqueButton();
		clickOnSignatureTeletravailArchivageLink();

		System.out.println("filtres");
		String[] textLines = { "Solution d'archivage électronique (SAE)",
				"Solution d'archivage électronique à valeur probante", "Solution de signature électronique",
				"Télétransmissions fiscales", "Télétransmissions sociales", "Récupération des relevés bancaires",
				"Intègre une solution IA", "Certifié eIDAS", "Hébergement des données en UE" };
		verifyTextLinesInPageSource(textLines);
		attachScreenshot("After checking filters");
	}

	@Step("Click on the 'Thématiques' button and take a screenshot")
	private void clickOnThematiqueButton() {
		try {
			// Localiser le bouton par son texte ou attribut unique
			WebElement thematiqueButton = driver
					.findElement(By.xpath("/html/body/div[1]/header/div[2]/div/div[1]/div/div/div[1]/button/span"));

			// Cliquer sur le bouton
			thematiqueButton.click();
			// Capture d'écran
			attachScreenshot("Clicked on 'Thématiques'");
		} catch (Exception e) {
			throw new RuntimeException("Failed to click on 'Thématiques' button: " + e.getMessage());
		}
	}

	@Step("Open login page")
	private void openLoginPage() {
		driver.get(
				"https://identification-rec.experts-comptables.org/cas/login?service=https%3A%2F%2Fgsn-rec.experts-comptables.org%2Fcas%2Fcallback");
	}

	@Step("Set browser window size")
	private void setWindowSize() {
		driver.manage().window().setSize(new Dimension(1854, 1048));
	}

	@Step("Enter username: {username}")
	private void enterUsername(String username) {
		WebElement usernameField = driver.findElement(By.id("username"));
		usernameField.click();
		usernameField.sendKeys(username);
	}

	@Step("Enter password")
	private void enterPassword(String password) {
		WebElement passwordField = driver.findElement(By.id("password"));
		passwordField.click();
		passwordField.sendKeys(password);
	}

	@Step("Click submit button")
	private void clickSubmitButton() {
		driver.findElement(By.id("experpass_submit_button")).click();
	}

	@Step("Attach screenshot: {name}")
	private void attachScreenshot(String name) {
		byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		Allure.addAttachment(name, new ByteArrayInputStream(screenshot));
	}

	@Step("Click on link with text '2'")
	private void clickOnLinkText2() {
		// Extraire l'URL à partir de l'attribut href
		String url = "https://gsn-rec.experts-comptables.org?page=2";

		// Naviguer directement vers l'URL
		driver.get(url);

		// Capture d'écran pour Allure
		attachScreenshot("Navigated to page 2 using href");
	}

	@Step("Click on link with text '3'")
	private void clickOnLinkText3() {
		String url = "https://gsn-rec.experts-comptables.org?page=3";

		// Naviguer directement vers l'URL
		driver.get(url);
		attachScreenshot("Clicked on link with text 3");
	}

	/*
	 * @Step("Wait until the URL is '{expectedUrl}' and perform actions") private
	 * void waitForUrlAndPerformActions(String expectedUrl) { // Définir une attente
	 * explicite avec une durée maximale WebDriverWait wait = new
	 * WebDriverWait(driver, Duration.ofSeconds(30));
	 * 
	 * // Attendre que l'URL soit celle attendue
	 * wait.until((ExpectedCondition<Boolean>) webDriver ->
	 * driver.getCurrentUrl().equals(expectedUrl) );
	 * attachScreenshot("Page loaded with URL: " + expectedUrl);
	 * 
	 * // Effectuer les actions une fois l'URL confirmée clickOnLinkText2();
	 * clickOnLinkText3(); }
	 */

	@Step("Wait until the page is fully loaded with URL: '{expectedUrl}'")
	private void waitForUrlAndPerformActions(String expectedUrl) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30)); // Attente maximale configurable

		// Attendre que l'URL soit celle attendue
		wait.until(ExpectedConditions.urlToBe(expectedUrl));

		// Vérifier que le document est complètement chargé
		wait.until(webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState")
				.equals("complete"));

		// Joindre une capture d'écran pour confirmer le chargement complet
		attachScreenshot("Page fully loaded with URL: " + expectedUrl);
	}

	@Step("Click on the 'PDP' link and take a screenshot")
	private void clickOnPDPLink() {
		
		
		try {
			// Localiser le lien par son texte exact
			WebElement pDPLink = driver.findElement(By.linkText("PDP"));
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			// Cliquer sur le lien
			pDPLink.click();

			// Capture d'écran après le délai
			attachScreenshot("PDP' after 8 seconds");
		} catch (Exception e) {
			throw new RuntimeException("Failed to click on PDP link: " + e.getMessage());
		}
	}

	@Step("Click on the 'Gestion patrimoine' link and take a screenshot")
	private void clickOnGestionPatrimoineLink() {
		try {
			// Localiser le lien par son texte exact
			WebElement gestionPatrimoineLink = driver.findElement(By.linkText("Gestion patrimoine"));
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			// Cliquer sur le lien
			gestionPatrimoineLink.click();

			// Capture d'écran après le délai
			attachScreenshot("Gestion patrimoine' after 8 seconds");
		} catch (Exception e) {
			throw new RuntimeException("Failed to click on Gestion patrimoine link: " + e.getMessage());
		}
	}

	@Step("Click on the 'Juridique-Fiscal' link and take a screenshot")
	private void clickOnJuridiqueFiscalLink() {
		try {
			// Localiser le lien par son texte exact
			WebElement juridiqueFiscalLink = driver.findElement(By.linkText("Juridique - Fiscal"));
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			// Cliquer sur le lien
			juridiqueFiscalLink.click();

			// Capture d'écran après le délai
			attachScreenshot("Juridique-Fiscal'");
		} catch (Exception e) {
			throw new RuntimeException("Failed to click on Juridique-Fiscal link: " + e.getMessage());
		}
	}

	@Step("Click on the 'Comptabilité - Précomptabilité' link and take a screenshot")
	private void clickOnComptabilitePrecomptabiliteLink() {
		try {
			// Localiser le lien par son texte exact

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			WebElement comptabilitePrecomptabiliteLink = wait.until(ExpectedConditions.visibilityOfElementLocated(
					By.linkText("Comptabilité - Précomptabilité")));
			// Cliquer sur le lien
			comptabilitePrecomptabiliteLink.click();

			// Capture d'écran après le délai
			attachScreenshot("Clicked on 'Comptabilité - Précomptabilité' after 8 seconds");
		} catch (Exception e) {
			throw new RuntimeException("Failed to click on 'Comptabilité - Précomptabilité' link: " + e.getMessage());
		}
	}

	@Step("Click on the 'Comptabilité - Précomptabilité' link and take a screenshot")
	private void clickOnDataLink() {
		try {
			// Localiser le lien par son texte exact
			WebElement dataLink = driver.findElement(By.linkText("Data"));
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			// Cliquer sur le lien
			dataLink.click();

			// Capture d'écran après le délai
			attachScreenshot("Clicked on 'Data' after 8 seconds");
		} catch (Exception e) {
			throw new RuntimeException("Failed to click on 'Data' link: " + e.getMessage());
		}
	}

	@Step("Click on the Social-RH link and take a screenshot")
	private void clickOnSocialRHLink() {
		try {
			// Localiser le lien par son texte exact
			WebElement socialRHLink = driver.findElement(By.linkText("Social - RH"));
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			// Cliquer sur le lien
			socialRHLink.click();

			// Capture d'écran après le délai
			attachScreenshot("Clicked on 'Social-RH' after 8 seconds");
		} catch (Exception e) {
			throw new RuntimeException("Failed to click on 'Social-RH' link: " + e.getMessage());
		}
	}

	@Step("Click on the Gestion interne & Commercialelink and take a screenshot")
	private void clickOnGestionInterneCommercialeLink() {
		try {
			// Localiser le lien par son texte exact
			// XPath avec contains()
			WebElement gestionInterneCommercialeLLink = driver
					.findElement(By.linkText("Gestion interne & Commerciale"));
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			// Cliquer sur le lien
			gestionInterneCommercialeLLink.click();

			// Capture d'écran après le délai
			attachScreenshot("Clicked on 'Gestion interne & Commerciale' after 8 seconds");
		} catch (Exception e) {
			throw new RuntimeException("Failed to click on 'Gestion interne & Commerciale' link: " + e.getMessage());
		}
	}

	@Step("Click on the 'Durabilité' link and take a screenshot with load time")
	private void clickOnDurabiliteLink() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));

			// Localiser le lien par son texte exact
			WebElement durabiliteLink = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Durabilité")));

			// Démarrer le chronomètre avant de cliquer
			long startTime = System.currentTimeMillis();

			// Cliquer sur le lien
			durabiliteLink.click();

			// Attendre que la page soit complètement chargée
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(), 'Durabilité')]")));

			// Arrêter le chronomètre après le chargement de la page
			long endTime = System.currentTimeMillis();

			// Calculer le temps de chargement
			long loadTime = (endTime - startTime) / 1000;

			// Ajouter le temps de chargement dans le texte de la capture d'écran
			attachScreenshot("Page 'Durabilité' chargée en " + loadTime + " ms");
		} catch (Exception e) {
			throw new RuntimeException("Failed to click on 'Durabilité' link: " + e.getMessage());
		}
	}

	@Step("Click on the Gestion trésorerie-financement link and take a screenshot")
	private void clickOnGestionTresorerieFinancementLink() {
		try {
			// Localiser le lien par son texte exact
			WebElement gestionTresorerieFinancementLink = driver
					.findElement(By.linkText("Gestion de trésorerie - Financement"));
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			// Cliquer sur le lien
			gestionTresorerieFinancementLink.click();
			// Capture d'écran après le délai
			attachScreenshot("Clicked on 'Gestion trésorerie-financement' after 8 seconds");
		} catch (Exception e) {
			throw new RuntimeException("Failed to click on 'Gestion trésorerie-financement' link: " + e.getMessage());
		}
	}

	@Step("Click on the Signature électronique, Télétransmission, archivage link and take a screenshot")
	private void clickOnSignatureTeletravailArchivageLink() {
		try {
			// Localiser le lien par son texte exact
			WebElement signatureTeletravailArchivageLink = driver
					.findElement(By.linkText("Signature électronique - Télétransmission - Archivage"));
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			// Cliquer sur le lien
			signatureTeletravailArchivageLink.click();

			// Capture d'écran après le délai
			attachScreenshot("Clicked on 'Signature électronique, Télétransmission, archivage' after 8 seconds");
		} catch (Exception e) {
			throw new RuntimeException(
					"Failed to click on 'Signature électronique, Télétransmission, archivage' link: " + e.getMessage());
		}
	}

	@Step("Verify if each line of the text exists in the page source with wait")
	private void verifyTextLinesInPageSource(String[] textLines) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60)); // Augmenter le délai d'attente

		for (String line : textLines) {
			System.out.println("Vérification de la ligne dans le filtre : " + line);

			try {
				// Attendre que le texte soit présent dans le DOM
				boolean isPresent = wait
						.until(driver -> driver.getPageSource().toLowerCase().contains(line.toLowerCase()));

				// Capturer un log si le texte n'est pas trouvé
				if (!isPresent) {
					System.out.println("Texte non trouvé dans le filtre : " + line);
				}

				// Assertion
				Assert.assertTrue(isPresent, "Texte non trouvé dans le code source de la page : " + line);
			} catch (TimeoutException e) {
				// Capturer une capture d'écran en cas d'échec

				throw new RuntimeException("TimeoutException lors de la vérification du texte : " + line, e);
			}
		}
	}

	@Step("Verify if each line of the text exists in the page source with wait and in the correct order")
	private void verifyTextLinesInPageSourcePDP(String[] textLines) {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60)); // Augmenter le délai d'attente

	    // Récupérer le contenu de la page
	    String pageSource = driver.getPageSource().toLowerCase();

	    int lastIndex = -1; // Pour suivre la position du dernier texte trouvé

	    for (String line : textLines) {
	        System.out.println("Vérification de la ligne dans le filtre : " + line);

	        try {
	            // Attendre que le texte soit présent dans le DOM
	            boolean isPresent = wait.until(driver -> driver.getPageSource().toLowerCase().contains(line.toLowerCase()));

	            if (!isPresent) {
	                System.out.println("Texte non trouvé dans le filtre : " + line);
	                Assert.fail("Texte non trouvé dans le code source de la page : " + line);
	            }

	            // Vérifier l'ordre des textes
	            int currentIndex = pageSource.indexOf(line.toLowerCase());
	            if (currentIndex < lastIndex) {
	                Assert.fail("L'ordre des textes est incorrect. Le texte '" + line + "' apparaît avant le texte précédent.");
	            }
	            lastIndex = currentIndex;

	        } catch (TimeoutException e) {
	            // Capturer une capture d'écran en cas d'échec
	            attachScreenshot("TimeoutException lors de la vérification du texte : " + line);
	            throw new RuntimeException("TimeoutException lors de la vérification du texte : " + line, e);
	        }
	    }
	}
	
	@AfterClass
	@Step("Tear down and close browser")
	public void teardown() {
		if (driver != null) {
			driver.quit();
		}
	}
}
