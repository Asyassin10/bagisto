package com.testgsn;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.AssertJUnit;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.qameta.allure.Allure;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import io.qameta.allure.testng.AllureTestNg;

import java.io.ByteArrayInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang3.StringEscapeUtils;

@Listeners({AllureTestNg.class})
public class TestComparateur {

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeClass
    @Step("Setup WebDriver and initialize browser")
    public void setup() throws MalformedURLException {
        FirefoxOptions options = new FirefoxOptions();
        driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), options);
        // Définit des délais d'attente globaux
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30)); // Implicit Wait
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30)); // Page Load Timeout

        // Initialise Explicit Wait pour toute la classe
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    @Test(priority = 12, description = "Test login functionality on the home page")
    @Step("Test login page flow")
    @Description("test de page login premiere etapes")
    public void pageHome() {
        openLoginPage();
        setWindowSize();
        enterUsername("pdurant12");
        enterPassword("Csoec!2017");
        clickSubmitButton();
        attachScreenshot("Final screen after login");
         waitForUrlAndPerformActions("https://gsn-rec.experts-comptables.org/");
    }

    @Test(priority = 13, description = "Test page Comptabilité")
    @Description("Test page comptabilité fonctionnalités")
    public void pageComptabilite() {
        clickOnThematiqueButton();
        clickOnComptabilitePrecomptabiliteLink();
        System.out.println("page comptabilite");
        Allure.addDescription("page comptabilite : clicker sur le boutton thematiques,clicker sur lien Comptabilité - Précomptabilité");
        attachScreenshot("apres checking Comptabilité - Précomptabilité");
    }
    // Méthode générique pour attendre et cliquer sur le bouton "Comparer"
	/*
	 * private void clickCompareButton(String xpath) { try { WebDriverWait wait =
	 * new WebDriverWait(driver, Duration.ofSeconds(30));
	 * 
	 * // Attendre que l'élément "Comparer" soit visible WebElement compareButton =
	 * wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
	 * 
	 * // Attendre que le bouton "Comparer" soit cliquable
	 * wait.until(ExpectedConditions.elementToBeClickable(compareButton));
	 * 
	 * // Faire défiler vers l'élément si nécessaire (en cas d'éléments recouvrants)
	 * ((JavascriptExecutor)
	 * driver).executeScript("arguments[0].scrollIntoView(true);", compareButton);
	 * 
	 * // Cliquer sur le bouton "Comparer" compareButton.click();
	 * System.out.println("Bouton 'Comparer' cliqué."); } catch
	 * (ElementClickInterceptedException e) { System.out.
	 * println("Erreur Selenium : L'élément est obstrué par un autre élément."); }
	 * catch (Exception e) { System.out.println("Erreur Selenium : " +
	 * e.getMessage()); } }
	 */
    @Test(priority = 16, description = "Test pour la carte NETexcom ma-comptabilite.com")
    @Description("Vérifie les fonctionnalités de la carte NETexcom ma-comptabilite.com")
    public void testCardNetexcom() {
        clickCompareButton("/html/body/div[1]/main/div[2]/div/div[2]/div[2]/div/div[3]/div/div[2]/a[1]");
        attachScreenshot("NETexcom ma-comptabilite.com  est ajouter");
        
        
    }

    @Test(priority = 15, description = "Test pour la carte Gretchen Armstrong")
    @Description("Vérifie les fonctionnalités de la carte Gretchen Armstrong")
    public void testCardGretchenArmstrong() {
        String xpath = "/html/body/div[1]/main/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/a[1]";
        clickCompareButton(xpath);
        attachScreenshot("Gretchen Armstrong est ajouté");
    }

    private void clickCompareButton(String xpath) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60)); // Augmenter le délai

            // Attendre que l'élément soit présent dans le DOM
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));

            // Attendre que l'élément soit visible
            WebElement compareButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));

            // Faire défiler vers l'élément si nécessaire
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", compareButton);

            // Cliquer sur le bouton
            compareButton.click();
            System.out.println("Bouton 'Comparer' cliqué.");
        } catch (Exception e) {
            System.out.println("Erreur : Temps d'attente dépassé pour localiser l'élément avec XPath : " + xpath);
            // Capturer une capture d'écran
         //   File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
          //  System.out.println("Capture d'écran sauvegardée : " + screenshotFile.getAbsolutePath());
        } 
    }

    @Test(priority = 17, description = "Test pour la carte Jael Alvarado")
    @Description("Vérifie les fonctionnalités de la carte Jael Alvarado")
    public void testCardJaelAlvarado() {
        clickCompareButton("/html/body/div[1]/main/div[2]/div/div[2]/div[2]/div/div[2]/div/div[2]/a[1]");
        attachScreenshot("Jael Alvarado est ajouter");
    }




    public void scrollToElement(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
    }

    public void clickCompareButtonForCard(String cardName) {
        List<WebElement> cards = driver.findElements(By.cssSelector(".responsive-grid"));
        for (WebElement card : cards) {
            String name = card.findElement(By.cssSelector(".truncate-name")).getText();
            if (name.equals(cardName)) {
                WebElement compareButton = card.findElement(By.cssSelector(".btn-card.comparer-btn"));
                compareButton.click();
                System.out.println("Bouton 'Comparer' cliqué pour : " + cardName);
                return;
            }
        }
        AssertJUnit.fail("Impossible de trouver le bouton 'Comparer' pour : " + cardName);
    }

    @Step("Open login page")
    private void openLoginPage() {
        driver.get("https://identification-rec.experts-comptables.org/cas/login?service=https%3A%2F%2Fgsn-rec.experts-comptables.org%2Fcas%2Fcallback");
    }

    @Step("Set browser window size")
    private void setWindowSize() {
        driver.manage().window().setSize(new Dimension(1854, 1048));
    }

    @Step("Enter username: {username}")
    private void enterUsername(String username) {
        WebElement usernameField = driver.findElement(By.id("username"));
        usernameField.click();
        usernameField.sendKeys(username);
    }

    @Step("Enter password")
    private void enterPassword(String password) {
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.click();
        passwordField.sendKeys(password);
    }

    @Step("Click submit button")
    private void clickSubmitButton() {
        driver.findElement(By.id("experpass_submit_button")).click();
    }

    @Step("Attach screenshot: {name}")
    private void attachScreenshot(String name) {
        byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
        Allure.addAttachment(name, new ByteArrayInputStream(screenshot));
    }

    @Step("Wait until the page is fully loaded with URL: '{expectedUrl}'")
    private void waitForUrlAndPerformActions(String expectedUrl) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30)); // Attente maximale configurable

        // Attendre que l'URL soit celle attendue
        wait.until(ExpectedConditions.urlToBe(expectedUrl));

        // Vérifier que le document est complètement chargé
        wait.until(webDriver -> ((JavascriptExecutor) webDriver)
                .executeScript("return document.readyState").equals("complete"));

        // Joindre une capture d'écran pour confirmer le chargement complet
        attachScreenshot("Page fully loaded with URL: " + expectedUrl);
    }

    @Step("Click on the 'Thématiques' button and take a screenshot")
    private void clickOnThematiqueButton() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        try {
            WebElement thematiqueButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[span[text()='Thématiques']]")));
            thematiqueButton.click();
            attachScreenshot("Clicke sur 'Thématiques'");
        } catch (Exception e) {
            throw new RuntimeException("Failed to click on 'Thématiques' button: " + e.getMessage());
        }
    }

    @Step("Click on the 'Comptabilité - Précomptabilité' link and take a screenshot")
    private void clickOnComptabilitePrecomptabiliteLink() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        try {
            WebElement comptabiliteLink = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Comptabilité - Précomptabilité")));
            comptabiliteLink.click();
            attachScreenshot("Clicke sur 'Comptabilité - Précomptabilité' ");
        } catch (Exception e) {
            throw new RuntimeException("Failed to click on 'Comptabilité - Précomptabilité' link: " + e.getMessage());
        }
    }

    @Test(priority = 25, description = "Test pour cliquer sur le bouton 'Comparer' et attendre le rendu de la page")
    @Description("Clique sur le bouton 'Comparer' et attend le rendu avant de capturer l'écran")
    public void testCompareButtonClick() {
        attachScreenshot("avant");

        // Étape 1: Naviguer vers la section contenant le bouton "Comparer"
        WebElement afficher = driver.findElement(By.id("comparator-dropdown-text"));

        // Étape 2: Attendre que le bouton "Comparer" soit cliquable et cliquer
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        wait.until(ExpectedConditions.elementToBeClickable(afficher)).click();

        WebElement comparer = wait.until(ExpectedConditions.elementToBeClickable(By.className("comparator-button")));
        comparer.click();

        // Étape 3: Attendre que la page du comparateur se rende
        WebElement h1Element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(), 'Comparateur')]")));
        System.out.println("Le bouton 'Comparer' a été cliqué et la page attendue a été rendue.");

        // Étape 4: Capturer une capture d'écran après le rendu
        if (h1Element != null) {
            attachScreenshot("rendu page comparer");
        }
    }
    

    @Test(priority = 26, description = "Test vérifier les champs")
    @Description("Vérifier la présence de certains textes dans la source de la page")
    public void verifyTextsInPageSource() {
        // Take a screenshot before performing actions
        attachScreenshot("before_verification");
        driver.navigate().to("https://gsn-rec.experts-comptables.org");
        clickOnThematiqueButton(); 
        try {
            Thread.sleep(5000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
        } catch (InterruptedException e) {  e.printStackTrace(); // En cas d'exception, afficher l'erreur
        }
            
        clickOnComptabilitePrecomptabiliteLink();

        // Attendre pendant 5 secondes avant de cliquer sur l'élément
        try {
            Thread.sleep(10000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
        } catch (InterruptedException e) {  e.printStackTrace(); // En cas d'exception, afficher l'erreur
        }
        WebElement element = driver.findElement(By.xpath("//a[contains(text(), 'Voir la fiche')]"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);

        try {
            Thread.sleep(5000); // Met en pause l'exécution pendant 5000 millisecondes (5 secondes)
        } catch (InterruptedException e) {  e.printStackTrace(); // En cas d'exception, afficher l'erreur
        }
        // Liste des éléments à vérifier
        String[] elementsToCheck = {
        		 "Solution de comptabilité ou de précomptabilité",
         	    "Comptabilité générale",
         	    "Comptabilité analytique",
         	    "Rapprochement bancaire et lettrage",
         	    "Module de paiement automatique",
         	    "Cachet qualifié ou signature électronique",
         	    "Gestion de la paie",
         	    "Gestion des cotisations TNS",
         	    "Module de facturation compatible facturation électronique",
         	    "Gestion des immobilisations",
         	    "Gestion de l'IR",
         	    "Gestion des notes de frais",
         	    "Module OCR intégré",
         	    "Gestion de secteurs particuliers (BTP, associations, ...)",
         	    "Édition de la liasse fiscale",
         	    "Module de datavisualisation de données paramétrable",
         	    "Prévisionnels de budget",
         	    "Prévisionnels CA",
         	    "Prévisionnels de trésorerie",
         	    "Analyses prédictives",
         	    "Accès par le client à son dossier",
         	    "Utilise un RPA (Robotic Process Automation)",
         	    "Intègre une solution IA",
         	    "Interopérabilité",
         	    "API disponibles",
         	    "Import de données",
         	    "Export de données personnalisable",
         	    "Intégration bureautique type Excel ou Power BI",
         	    "Interopérable avec un logiciel de facturation",
         	    "Interopérable avec des PDP",
         	    "Interopérable avec un logiciel d’achat",
         	    "Gestion de l'EBICS",
         	    "Interopérable avec un système de conservation ou d’archivage",
         	    "Interopérable avec un coffre-fort",
         	    "Interopérable avec un CRM / GRC",
         	    "Interopérable avec des solutions métier",
         	    "Conformité",
         	    "Conforme RGPD",
         	    "Mise à jour avec les nouvelles règlementations",
         	    "Accessibilité",
         	    "Accès cloud",
         	    "Application mobile disponible",
         	    "Sécurité des données",
         	    "Hébergement des données en UE",
         	    "Plan de récupération en cas de cyber attaque",
         	    "Confidentialité des données",
         	    "Support / Formation",
         	    "Hot line",
         	    "Chat bot",
         	    "Formation des utilisateurs",
         	    "Structure tarifaire",
         	    "Mode de tarification",
         	    "Coût de maintenance inclus",
         	    "Mises à jour gratuites",
         	    "Les 3 atouts de la solution",
         	    "Prérequis",
         	    "Fait partie d'une suite logicielle"

        	};

        for (String el : elementsToCheck) {
            // Escape single quotes in the XPath expression
            String xpathExpression = "//*[contains(text(),\"" + el + "\")]";
           // System.out.print("xpathExpression => " + xpathExpression);
            List<WebElement> foundElements = driver.findElements(By.xpath(xpathExpression));

            // Display if the element is found or not
            if (foundElements.size() > 0) {
                System.out.println("Élément trouvé : " + el);
                Allure.addAttachment("Élément trouvé : " + el, "");
            } else {
                System.out.println("Élément non trouvé : " + el);
                Allure.addAttachment("Élément non trouvé : " + el, "");
            }
        }

        attachScreenshot("after_verification");
    }

		
    
    
	/*
	 * public void verifyTextsInPageSource() { // Liste des textes à vérifier
	 * List<String> expectedTexts = Arrays.asList(
	 * 
	 * 
	 * );
	 * 
	 * // Masquer la barre de débogage phpdebugbar si présente WebElement debugBar =
	 * driver.findElement(By.className("phpdebugbar-tab")); ((JavascriptExecutor)
	 * driver).executeScript("arguments[0].style.display='none';", debugBar);
	 * 
	 * // Attendre que le bouton soit cliquable avant de cliquer WebDriverWait wait
	 * = new WebDriverWait(driver, Duration.ofSeconds(30)); WebElement comparer =
	 * wait.until(ExpectedConditions.elementToBeClickable(By.className("btn-voici"))
	 * );
	 * 
	 * // Cliquer sur le bouton comparer.click();
	 * 
	 * // Capture d'écran après le clic
	 * attachScreenshot("After clicking on 'Comparer' and waiting for the page to render"
	 * );
	 * 
	 * // Récupérer le code source de la page String pageSource =
	 * driver.getPageSource();
	 * 
	 * // Vérifier chaque texte attendu dans la page source for (String text :
	 * expectedTexts) { // Utilisation de StringEscapeUtils pour s'assurer que les
	 * caractères spéciaux HTML sont correctement échappés boolean isTextPresent =
	 * pageSource.contains(StringEscapeUtils.escapeHtml4(text));
	 * Assert.assertTrue(isTextPresent, "Le texte suivant est introuvable : " +
	 * text); } }
	 * 
	 */   
    @AfterClass
	@Step("Tear down and close browser")
	public void teardown() {
		if (driver != null) {
			driver.quit();
		}
	}
}
