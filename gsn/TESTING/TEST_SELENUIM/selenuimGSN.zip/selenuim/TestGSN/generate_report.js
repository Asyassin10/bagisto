const puppeteer = require('puppeteer');
const fs = require('fs');
const pdf = require('pdf-lib');  // Pour fusionner les fichiers PDF

(async () => {
  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();

  const urls = [
    'http://0.0.0.0:8000/'  // URL de votre rapport Allure
  ];

  let pdfBuffers = [];

  for (let url of urls) {
    await page.goto(url, { waitUntil: 'networkidle0' });

    // Attendre que le bouton "Show all" soit visible
    await page.waitForSelector('.table__row a'); // Remplacez par le sélecteur exact du lien "Show all"

    // Cliquer sur le bouton "Show all"
    await page.click('.table__row a'); // Remplacez par le sélecteur exact du lien "Show all"

    // Attendre que le contenu soit complètement chargé après le clic
    await page.waitForSelector('#behaviors', { visible: true });  // Attendre un élément clé pour garantir que la page est bien chargée

    // Générer un PDF de cette page après le clic
    const pdfBuffer = await page.pdf({ format: 'A4' });

    // Ajouter le buffer généré au tableau des PDF
    pdfBuffers.push(pdfBuffer);

    // Optionnel : attendez un autre clic ou retour à une autre page si nécessaire
  }

  await browser.close();

  // Fusionner les PDF dans un seul fichier
  const mergedPdf = await pdf.PDFDocument.create();

  for (const buffer of pdfBuffers) {
    const existingPdf = await pdf.PDFDocument.load(buffer);
    const copiedPages = await mergedPdf.copyPages(existingPdf, existingPdf.getPages().map((_, i) => i));
    copiedPages.forEach((page) => mergedPdf.addPage(page));
  }

  const finalPdfBytes = await mergedPdf.save();

  // Sauvegarder le fichier PDF fusionné
  fs.writeFileSync('allure_report_complete.pdf', finalPdfBytes);
})();
